//step1 Import all predefined modules
var express = require('express');
 var cors = require("cors");
var mongoose = require("mongoose");
var bodyParser = require("body-parser");
var path=require('path');
//import Product defined module
var Product = require('./models/product.model');
//creating app object to start server
var app = express();
//step3: Connect your Mongodb -mongodb url
mongoose.connect('mongodb://localhost:27017/products', { useNewUrlParser: true });
//Step:4 Configure Middleware
//parse requests of Encoding-Type-
//application/x-wwww-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }));

//parse requests of content-type -application/json
app.use(bodyParser.json());
//Step 5: Define Routes
//create router object to create user friendly urls
//routes logic will come here
var router = express.Router();
//create
router.route('/products').post(function (req, res, next) {
    var product = new Product();
    product.prodId=req.body.prodId;
    product.prodName = req.body.prodName;
    product.description=req.body.description;
    product.address = req.body.address;
    product.price = req.body.price;
   product.quantity = req.body.quantity;
 

    product.save(function (err) {
        if (err) {
            res.send(err.stack);
            return;
        }
        console.log("added");
        res.send({ message: ' Product  created !' })
    })
});

//read
router.route('/products').get(function (req, res) {
    Product.find(function (err, products) {
        if (err) {
            res.send(err.stack);
            return;
        }
        res.send(products);
    });
});
//get by Id
router.route('/products/:id')
    .get(function (req, res) {
       Product.findById(req.params.id,{__v:0},
             function (err, product) {
            if (err) {
                res.send(err.stack);
                return;
            }
            res.json(product);
        });
    });
//update
router.route('/products/:id')
    .put(function (req, res) {
       Product.findById(req.params.id,
            function (err, product) {
                if (err) {
                    res.send(err.stack);
                    return;
                }
                product.prodId=req.body.prodId;
                product.prodName = req.body.prodName;
                product.description=req.body.description;
                product.address = req.body.address;
                product.price = req.body.price;
                product.quantity = req.body.quantity;
                product.save(function (err) {
                    if (err) {
                        res.send(err.stack);
                    }
                    res.json({ message: ' Product  Updated!' });

                });
            });
    });

//delete
router.route('/products/:id')
    .delete(function (req, res) {
       Product.remove({ _id: req.params.id },
            function (err, product) {
                if (err) {
                    res.send(err.stack);
                    return;
                }
                res.json({ message: ' Product  Successfully deleted' });

            });
       
    });

     app.use(cors());
    app.use('/api',router);
    app.listen(8090);

    console.log('Rest Api is running at 8090');