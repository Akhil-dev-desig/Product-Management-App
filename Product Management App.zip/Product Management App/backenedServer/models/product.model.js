//step1: Import Mongoose Model
var mongoose= require('mongoose');
const Schema=mongoose.Schema;

let Product=new Schema({
    prodId:String,
    prodName:String,
    description:String,
    address:String,
    price:Number,
    quantity:Number,
   
})
//Step4: Export Schema
module.exports=mongoose.model('Product',Product);