import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { AddProductComponent } from './components/add-product/add-product.component';
import { EditProductComponent } from './components/edit-product/edit-product.component';
import { ListProductComponent } from './components/list-product/list-product.component';
import { ProductsComponent } from './components/products/products.component';

const routes: Routes = [
{path:'home',component:HomeComponent},
{path:'login',component:LoginComponent},
// {path:'edit-product',component:EditProductComponent},
{path:'add-product',component:AddProductComponent},
{path:'list-product',component:ListProductComponent},
{path:'edit-product/:id',component:EditProductComponent},
{path:'product',component:ProductsComponent},
{path:'',component:HomeComponent},
{path:'**',component:HomeComponent},



];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
