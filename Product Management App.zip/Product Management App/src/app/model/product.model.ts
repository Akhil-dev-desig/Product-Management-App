export class Product{
    _id:string;
    prodId:string;
    prodName:string;
    description:string;
    price:string;
   
}