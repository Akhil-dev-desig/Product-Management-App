import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Product } from '../model/product.model';


@Injectable({
  providedIn: 'root'
})
export class ProductsService {


  constructor(private http: HttpClient) { }

  baseUrl: string = "http://localhost:8090/api/products";
  //Get all products
  getProducts() {
    return this.http.get<Product[]>(this.baseUrl);
  }
  //GetProducts By Id
  getProductsById(id: string) {
    return this.http.get<Product>(this.baseUrl + "/" + id);

  }
  //Add Products
  createProduct(Product: Product) {
    return this.http.post(this.baseUrl, Product);

  }
  //Modify Product
  updateProduct(Product: Product) {
    return this.http.put(this.baseUrl + "/" + Product._id, Product);

  }
  //Delete Products By Id
  deleteProduct(id: string) {
    return this.http.delete(this.baseUrl + "/" + id);
  }
}


