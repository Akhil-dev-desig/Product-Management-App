import { Component, OnInit } from '@angular/core';
import { ProductsService } from '../../services/products.service';
import{Router} from '@angular/router';
import {Product} from '../../model/product.model';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-list-product',
  templateUrl: './list-product.component.html',
  styleUrls: ['./list-product.component.css']
})
export class ListProductComponent implements OnInit {
  //creating an array of user class
products: Product[];
//filtering by name
searchText: any;

//constructor dependency Injection
  constructor(private router: Router,private productsService:ProductsService ) { }
//logOff product
logOutUser():void{
  if(localStorage.getItem("username")!=null){
    localStorage.removeItem("username");this.router.navigate(['/login']);
  }
}
  ngOnInit() {
    if(localStorage.getItem("username")!=null){
      this.productsService.getProducts().subscribe(data=>{this.products=data});
    }
    else{
      this.router.navigate(['/login']);
    }
  }
   //Delete Product
   deleteProduct(product: Product): void {
    let result = confirm("Do you want to delete Product?");
    if (result) {
      this.productsService.deleteProduct(product._id).subscribe(data => {
        this.products = this.products.filter(u => u !== product);
      })
      Swal.fire({
        title: 'Delete',
        text: 'Record is deleted Successfully',
      })
    }

  }
  //Add new Product
  addProduct(): void{
    this.router.navigate(['add-product']);
  }
  //Modify Product
  editProduct(product:Product): void{
    this.router.navigate(['edit-product',product._id.toString()]);
  }

    }



 
