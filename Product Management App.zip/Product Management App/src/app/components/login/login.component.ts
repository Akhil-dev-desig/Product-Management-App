import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import Swal from 'sweetalert2'
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {// Instance Variables
  //By default public in typescript
  loginForm: FormGroup;
  submitted: boolean = false;
  invalidLogin: boolean = false;
  //consructor Dependency Injection
  constructor(private formBuilder: FormBuilder, private router: Router) { }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      email: ['', Validators.required],
      password: ['', Validators.required],
    });
  }
  onSubmit() {
    this.submitted = true;
    //If validation failed,it should return
    //to validate again
    if (this.loginForm.invalid) {
      return;
    }
    let username = this.loginForm.controls.email.value;
    let password = this.loginForm.controls.password.value;
    if (username == "admin@gmail.com" && password == "123456") {
      localStorage.setItem("username", username);
      this.router.navigate(['list-product']);
      Swal.fire({
        type: 'success',
        title: 'Login',
        text: 'Login is Successful',

      })
    }
    else {
      this.invalidLogin = true;
      Swal.fire({
        type: 'error',
        title: 'Login',
        text: 'Invalid Username and Password',

      })
    }
  }
}

