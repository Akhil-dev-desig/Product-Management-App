import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { Product } from '../../model/product.model';
import { ProductsService } from '../../services/products.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-edit-product',
  templateUrl: './edit-product.component.html',
  styleUrls: ['./edit-product.component.css']
})
export class EditProductComponent implements OnInit {
  editForm: FormGroup;
  submitted: boolean = false;
  product: Product;
  productId: string;
  
  constructor(private formBuilder: FormBuilder, private router: Router, private route: ActivatedRoute,
    private productsService: ProductsService) {
    this.route.params.subscribe(params => this.productId = params['id']);
    console.log(this.productId);
  }
  //logOff Product
  logOutProduct(): void {
    if (localStorage.getItem("username") != null) {
      localStorage.removeItem("username");
      this.router.navigate(['/login']);
    }
  }
  ngOnInit() {

    if (this.productId != null) {
      if (!this.productId) {
        alert('Invalid Action');
        this.router.navigate(['/list-product']);
        return;
      }
      this.editForm = this.formBuilder.group({
        _id: [],
        prodId: ['', Validators.required],
        prodName: ['', Validators.required],
        description: ['', Validators.required],
        price: ['', Validators.required],

      });
      //pulling data from data base or json-server //using service
      this.productsService.getProductsById(this.productId).subscribe(data => {
        this.editForm.setValue(data)
      });
    }
    else {
      this.router.navigate(['/login']);

    }

  }//end of ngOnInit() function

  onSubmit() {
    this.submitted = true;
    if (this.editForm.invalid) {
      return;
    }
    this.productsService.updateProduct(this.editForm.value)
      
      .subscribe(data => {
        this.router.navigate(['list-product']);
         Swal.fire({
          title: 'Update',
          text: 'Record is Updated Successfully',
        })
      }, error => {
        alert(error);
      });
  }

}



