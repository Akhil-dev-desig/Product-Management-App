import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ProductsService } from '../../services/products.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {

  addForm:FormGroup;
  submitted:boolean =false;

  constructor(private formBuilder :FormBuilder,private router:Router,
    private productsService:ProductsService) { }

  ngOnInit() {
    this.addForm=this.formBuilder.group({
      id:[],
      prodId:['',Validators.required],
      prodName:['',Validators.required],
      description:['',Validators.required],
     price:['',Validators.required],
    
    });
  }
  //onSubmit() function
  onSubmit(){
    this.submitted=true;
    if(this.addForm.invalid){
      return;
    }
    this.productsService.createProduct(this.addForm.value).subscribe(data=>{
      // alert(this.addForm.controls.custName.value +'record is added successfully ..!');
      Swal.fire({
        title: 'Add Product',
        text: 'Record is Added  Successfully',
      })
      this.router.navigate(['list-product']);
    });
  }
}